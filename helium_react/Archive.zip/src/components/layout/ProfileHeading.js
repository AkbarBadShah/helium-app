import React from 'react';

export const ProfileHeading = () => {
    return (
        <div className="Profile_heading">
            <h4>
                Sustain 6
            </h4>
        </div>
    );
}