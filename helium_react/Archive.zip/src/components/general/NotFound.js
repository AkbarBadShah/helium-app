import React from "react";


export const NotFound = () => {
    return (
        <div>
           <p> Page Not Found</p>
        </div>
    );
}